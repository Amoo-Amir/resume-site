# 🎫 Support Ticket System API

یک API ساده و کارآمد برای مدیریت تیکت‌های پشتیبانی. مناسب برای پروژه‌های کوچک و متوسط.

---

## 🚀 **تکنولوژی‌های استفاده شده**

- Node.js + Express
- MongoDB + Mongoose
- JWT برای احرازویت
- bcrypt برای رمزنگاری پسورد
- express-validator برای اعتبارسنجی

---

## 📦 **نصب و راه‌اندازی**

```bash
# 1. کلون کردن پروژه
... دلیل‌قطعی‌اینترنت‌‌‌‌‌‌‌ ندارد
# 2. نصب وابستگی‌ها
npm install

# 3. ساخت فایل محیطی
cp .env.example .env

# 4. تنظیم متغیرهای محیطی در فایل .env
# - PORT: پورت سرور (پیش‌فرض: 3008)
# - MONGO_URI: آدرس دیتابیس MongoDB
# - JWT_SECRET: کلید مخفی برای توکن
# - ADMIN_SECRET_KEY: کلید مخفی برای ساخت ادمین

# 5. اجرای پروژه
nodemon app.js

# 6. تست با postman
```
user tests

# register user
request
POST /api/makeuser
Content-Type: application/json

{
  "name": "test1",
  "email": "test@gmail.com",
  "password": "12345678"
}
response:
{
  "success": true,
  "message": "User registered successfully",
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": "65f8a1b2...",
    "name": "test1",
    "email": "test@gmail.com",
    "role": "user"
  }
}

# register as admin
request:
POST /api/makeuser
Content-Type: application/json

{
  "name": "admin1",
  "email": "admin@gmail.com",
  "password": "12345678",
  "secretkey": "your_admin_secret_key_here"
}
response:
{
  "success": true,
  "message": "Admin created successfully",
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": "65f8a1b2...",
    "name": "admin1",
    "email": "admin@gmail.com",
    "role": "admin"
  }
}

# login user
request:
POST /api/login
Content-Type: application/json

{
  "email": "test@gmail.com",
  "password": "12345678"
}
response:
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": "65f8a1b2...",
    "name": "test1",
    "email": "test@gmail.com",
    "role": "user"
  }
}

# get prfile
# request:
GET /api/profile
Authorization: Bearer YOUR_TOKEN_HERE
# response:
{
  "success": true,
  "data": {
    "id": "65f8a1b2...",
    "name": "test1",
    "email": "test@gmail.com",
    "role": "user"
  }
}


# change user password
request:
PUT /api/passchange
Authorization: Bearer YOUR_TOKEN_HERE
Content-Type: application/json

{
  "oldpassword": "12345678",
  "newpassword": "87654321",
  "confirmnewpassword": "87654321"
}
response:
{
  "success": true,
  "message": "Password changed successfully"
}




ticket test

# make ticket
- request:
POST /api/maketicket
Authorization: Bearer YOUR_TOKEN_HERE
Content-Type: application/json

{
  "title": "test1",
  "description": "rest description",
  "category": "technical",
  "priority": "high"
}
- response:
{
  "success": true,
  "message": "Ticket created successfully",
  "data": {
    "_id": "65f8a1b2...",
    "title": "test1",
    "description": "rest description",
    "category": "technical",
    "priority": "high",
    "status": "open",
    "user": "65f8a1b2...",
    "createdAt": "2024-01-01T00:00:00.000Z"
  }
}

# get ticket
- request:
GET /api/tickets?page=1&limit=10&status=open
Authorization: Bearer YOUR_TOKEN_HERE
-response:
{
  "success": true,
  "message": "Tickets retrieved successfully",
  "data": {
    "tickets": [...],
    "pagination": {
      "currentPage": 1,
      "totalPages": 3,
      "totalItems": 25,
      "itemsPerPage": 10,
      "hasNextPage": true,
      "hasPrevPage": false
    }
  }
}

# get ticket by id
-request:
GET /api/tickets/65f8a1b2c3d4e5f6a7b8c9d0
Authorization: Bearer YOUR_TOKEN_HERE
- response:
{
  "success": true,
  "data": {
    "_id": "65f8a1b2...",
    "title": "test1",
    "description": "rest description",
    "status": "open",
    "replies": [...]
  }
}

# update ticket
- requser:
PUT /api/tickets/65f8a1b2c3d4e5f6a7b8c9d0
Authorization: Bearer YOUR_TOKEN_HERE
Content-Type: application/json

{
  "title": "new title",
  "priority": "medium"
}
- response:
{
  "success": true,
  "message": "Ticket updated successfully",
  "data": { ... }
}

# delete ticket
- request:
DELETE /api/tickets/65f8a1b2c3d4e5f6a7b8c9d0
Authorization: Bearer YOUR_TOKEN_HERE
- response:
{
  "success": true,
  "message": "Ticket deleted successfully"
}

# reply to ticket
- request:
POST /api/addreply/65f8a1b2c3d4e5f6a7b8c9d0
Authorization: Bearer YOUR_TOKEN_HERE
Content-Type: application/json

{
  "content": "This is my reply"
}
- response:
{
  "success": true,
  "message": "Reply added successfully",
  "data": {
    "reply": {
      "id": "65f8a1b2...",
      "content": "This is my reply",
      "createdAt": "2024-01-01T00:00:00.000Z",
      "user": {
        "id": "65f8a1b2...",
        "name": "test1"
      }
    }
  }
}