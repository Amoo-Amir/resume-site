
const mongoose = require("mongoose");

const ticketSchema = new mongoose.Schema(
  {
    ticketNumber: {
      type: String,
      unique: true,
      required: true,
    },
    title: {
      type: String,
      required: [true, "Title is required"],
      trim: true,
      maxlength: [200, "Title too long"],
    },
    description: {
      type: String,
      required: [true, "Description is required"],
      maxlength: [5000, "Description too long"],
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User2",
      required: true,
    },
    category: {
      type: String,
      enum: ["technical", "billing", "sales", "general", "complaint"],
      required: true,
    },
    priority: {
      type: String,
      enum: ["low", "medium", "high", "urgent"],
      default: "medium",
    },
    status: {
      type: String,
      enum: ["open", "in_progress", "resolved", "closed"],
      default: "open",
    },
    assignedTo: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    attachments: [
      {
        filename: String,
        url: String,
        uploadedAt: Date,
      },
    ],
    resolvedAt: Date,
    closedAt: Date,
    rating: {
      type: Number,
      min: 1,
      max: 5,
      default: null,
    },
    feedback: String,
  },
  {
    timestamps: true,
  },
);

ticketSchema.pre("validate", async function () {
  if (!this.ticketNumber) {
    const Ticket = mongoose.model("Ticket");
    const count = await Ticket.countDocuments();
    this.ticketNumber = `TKT-${(count + 1).toString().padStart(6, "0")}`;
  }
});

module.exports = mongoose.model("Ticket", ticketSchema);
