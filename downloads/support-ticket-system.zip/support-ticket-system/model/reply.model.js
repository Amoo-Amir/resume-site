const mongoose = require('mongoose');

const replySchema = new mongoose.Schema({
  ticket: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Ticket',
    required: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User2',
    required: true
  },
  content: {
    type: String,
    required: [true, "Reply content is required"],
    maxlength: [2000, "Reply too long"]
  },
  isInternal: {
    type: Boolean,
    default: false  
  },
  attachments: [{
    filename: String,
    url: String
  }],
  editedAt: Date
}, {
  timestamps: true
});

module.exports = mongoose.model('Reply', replySchema);