const express = require("express");
const router = express.Router();
const Usercontroller = require("../controller/user.controller");
const auth = require("../middleware/auth");

router.get("/profile", auth, Usercontroller.profile);

router.post("/makeuser", Usercontroller.makeuser);
router.post("/login", Usercontroller.login);
router.put("/passchange", auth, Usercontroller.changepassword);

module.exports = {
  router,
};
