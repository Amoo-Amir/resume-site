const express = require("express");
const ticketcontroller = require("../controller/ticket.controller");
const auth = require("../middleware/auth");
const router = express.Router();

router.post("/maketicket", auth, ticketcontroller.maketicket);
router.post("/addreply/:id", auth, ticketcontroller.addreply);
router.put("/tickets/:id", auth, ticketcontroller.updateTicket);
router.delete("/tickets/:id", auth, ticketcontroller.deleteTicket);

router.get("/tickets", auth, ticketcontroller.getmyTickets);
router.get("/tickets/:id", auth, ticketcontroller.getTicketById);

module.exports = {
  router,
};
