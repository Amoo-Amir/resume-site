const mongoose = require("mongoose");

async function DB() {
  await mongoose
    .connect(process.env.MONGO_URI)
    .then(() => {
      console.log("connected to mongodb");
    })
    .catch((err) => {
      console.log(err);
    });
}
module.exports = { DB };
