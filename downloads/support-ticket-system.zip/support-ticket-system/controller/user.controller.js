const User = require("../model/User.model");
const asyncHandler = require("../middleware/asyncHandler");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const makeuser = asyncHandler(async (req, res) => {
  const { name, email, password, secretkey } = req.body;

  let adminrole = "user";

  if (secretkey === process.env.ADMIN_SECRET_KEY) {
    adminrole = "admin";
  }

  if (!name?.trim() || !email?.trim() || !password) {
    return res.status(400).json({
      message: "All fields are required",
      required: ["name", "email", "password"],
    });
  }

  const emailexists = await User.findOne({
    email: String(email).toLowerCase().trim(),
  });

  if (emailexists) {
    return res.status(400).json({ message: "email alredy existed." });
  }

  if (password.length < 8) {
    return res.status(400).json({
      message: "Password must be at least 8 characters",
    });
  }

  const verifyemail = String(email).toLowerCase().trim();

  const hash = await bcrypt.hash(password, 10);

  if (!hash) {
    return res.status(500).json({ message: "cannt hash password." });
  }

  const newuser = await new User({
    email: verifyemail,
    name: name,
    password: hash,
    createdAt: new Date(),
    role: adminrole,
  });

  const saved = await newuser.save();
  if (!saved) {
    return res.status(500).json({ message: "cannt save user info." });
  }

  res.status(201).json({ success: true,saved });
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      message: "Email and password are required",
    });
  }

  const normalizeemail = String(email).toLowerCase().trim();

  const user = await User.findOne({ email: normalizeemail }).select(
    "+password",
  );
  if (!user) {
    return res.status(404).json({ message: "Invalid email or password" });
  }

  const passcompare = await bcrypt.compare(password, user.password);
  if (!passcompare) {
    return res.status(401).json({ message: "password is wrong!" });
  }

  const token = await jwt.sign(
    { userId: user._id, userRole: user.role },
    process.env.SECRET_KEYT,
    {
      expiresIn: "1d",
    },
  );

  res.status(200).json({
    message: "Login successful",
    email: user.email,
    ID: user._id,
    token,
  });
});

const profile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.userId);

  if (!user) {
    return res.status(403).json("user not found.");
  }

  res.status(201).json(user);
});

const changepassword = asyncHandler(async (req, res) => {
  const { oldpassword, newpassword, confirmnewpassword } = req.body;

  const user = await User.findOne({ _id: req.userId }).select("+password");

  console.log(req.userId);

  if (!user) {
    return res.status(404).json({
      success: false,
      message: "User not found",
    });
  }

  if (!oldpassword) {
    return res.status(403).json({ message: "password fild is empty." });
  }

  if (newpassword !== confirmnewpassword) {
    return res.status(403).json({
      success: false,
      message: "Password confirmation does not match the new password",
      field: "confirmNewPassword",
    });
  }

  const oldpass = await bcrypt.compare(oldpassword, user.password);

  if (!oldpass) {
    return res.status(401).json({
      success: false,
      message: "Authentication failed",
      error: "Invalid current password",
      field: "oldPassword",
    });
  }

  if (oldpassword === newpassword) {
    return res
      .status(403)
      .json({ message: "you cannt use your oldpassword again." });
  }

  user.password = await bcrypt.hash(newpassword, 10);
  await user.save();

  res.status(200).json({ message: "pasword updated." });
});

module.exports = {
  makeuser,
  login,
  profile,
  changepassword,
};
