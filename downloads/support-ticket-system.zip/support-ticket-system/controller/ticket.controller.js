const asynchandler = require("../middleware/asyncHandler");
const Ticket = require("../model/ticket.model");
const Reply = require("../model/reply.model");
const { default: mongoose } = require("mongoose");

const maketicket = asynchandler(async (req, res) => {
  const { title, description, category, priority } = req.body;

  if (!title || !description) {
    return res.status(400).json({ message: "fildes are empty." });
  }

  const newticket = new Ticket({
    title,
    description,
    category,
    priority,
    status: "open",
    user: req.userId,
  });
  console.log(req.userId);

  const saved = await newticket.save();

  res.status(200).json({ saved });
});

const getmyTickets = asynchandler(async (req, res) => {
  let { status, page = 1, limit = 10 } = req.query;

  page = parseInt(page, 10);
  limit = parseInt(limit, 10);

  if (isNaN(page) || page < 1) page = 1;
  if (isNaN(limit) || limit < 1) limit = 10;
  if (limit > 100) limit = 10;

  const filter = { user: req.userId };

  const verifystatus = ["open", "in-progress", "closed", "resolved"];
  if (status && verifystatus.includes(status.toLowerCase())) {
    filter.status = status;
  } else if (status) {
    return res.status(400).json({
      success: false,
      message: `Invalid status. Allowed values: ${validStatuses.join(", ")}`,
    });
  }

  let skip = (page - 1) * limit;

  const [tickets, total] = await Promise.all([
    Ticket.find(filter)
      .select("-__v")
      .populate("user", "name email")
      .sort({ createdAt: -1 })
      .limit(limit)
      .skip(skip)
      .lean(),

    Ticket.countDocuments(filter),
  ]);

  const totalPages = Math.ceil(total / limit);
  const hasNextPage = page < totalPages;
  const hasPrevPage = page > 1;

  res.status(200).json({
    success: true,
    message: "Tickets retrieved successfully",
    data: {
      tickets,
      pagination: {
        currentPage: page,
        totalPages,
        totalItems: total,
        itemsPerPage: limit,
        hasNextPage,
        hasPrevPage,
        nextPage: hasNextPage ? page + 1 : null,
        prevPage: hasPrevPage ? page - 1 : null,
      },
    },
  });
});

const getTicketById = asynchandler(async (req, res) => {
  const { id } = req.params;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({
      success: false,
      message: "ticket ID is not vaild.",
    });
  }

  const ticket = await Ticket.findById(id)
    .populate("user", "name email")
    .populate("Reply")
    .lean();

  if (!ticket) {
    return res.status(404).json({
      success: false,
      message: "Ticket not found",
    });
  }

  const isOwner = ticket.user._id.toString() === req.userId;
  const isAdmin = req.userRole === "admin";

  if (!isOwner && !isAdmin) {
    return res.status(403).json({
      success: false,
      message: "You don't have permission to view this ticket",
    });
  }

  res.status(200).json({
    success: true,
    data: ticket,
  });
});

const addreply = asynchandler(async (req, res) => {
  const { id } = req.params;
  const { content, isInternal = false } = req.body;

  if (!content || content.trim().length === 0) {
    return res.status(400).json({
      success: false,
      message: "Reply content cannot be empty",
    });
  }

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({
      success: false,
      message: "Invalid ticket ID format",
    });
  }

  const ticket = await Ticket.findById(id);
  if (!ticket) {
    return res.status(404).json({
      success: false,
      message: "Ticket not found",
    });
  }

  const isOwner = ticket.user.toString() === req.userId;

  if (!isOwner) {
    return res.status(403).json({
      success: false,
      message: "You do not have permission to reply to this ticket",
    });
  }

  if (ticket.status === "closed") {
    return res.status(400).json({
      success: false,
      message: "Cannot reply to a closed ticket",
    });
  }

  const newReply = new Reply({
    content: content.trim(),
    ticket: id,
    user: req.userId,
    isInternal: isInternal || false,
    createdAt: new Date(),
  });

  const saved = await newReply.save();
  const populatedReply = await Reply.findById(saved._id).populate(
    "user",
    "name email role",
  );

  res.status(201).json({
    success: true,
    message: isInternal
      ? "Internal reply added successfully"
      : "Reply added successfully",

    data: {
      reply: {
        populatedReply,
        id: newReply._id,
        content: newReply.content,
        isInternal: newReply.isInternal,
        createdAt: newReply.createdAt,
        user: {
          id: newReply.user._id,
          name: newReply.user.name,
          role: newReply.user.role,
        },
      },
    },
  });
});

const updateTicket = asynchandler(async (req, res) => {
  const { id } = req.params;
  const { title, description, category, priority } = req.body;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({
      success: false,
      message: "Invalid ticket ID format",
    });
  }

  const ticket = await Ticket.findById(id);
  if (!ticket) {
    return res.status(404).json({
      success: false,
      message: "Ticket not found",
    });
  }

  const isOwner = ticket.user.toString() === req.userId;
  const isAdmin = req.userRole === "admin";

  if (!isOwner && !isAdmin) {
    return res.status(403).json({
      success: false,
      message: "You don't have permission to delete this ticket",
    });
  }


  if (ticket.status === "closed") {
    return res.status(400).json({
      success: false,
      message: "Cannot update a closed ticket",
    });
  }

  if (title) ticket.title = title;
  if (description) ticket.description = description;
  if (category) ticket.category = category;
  if (priority) ticket.priority = priority;

  const updatedTicket = await ticket.save();

  res.status(200).json({
    success: true,
    message: "Ticket updated successfully",
    data: updatedTicket,
  });
});

const deleteTicket = asynchandler(async (req, res) => {
  const { id } = req.params;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({
      success: false,
      message: "Invalid ticket ID format",
    });
  }

  const ticket = await Ticket.findById(id);
  if (!ticket) {
    return res.status(404).json({
      success: false,
      message: "Ticket not found",
    });
  }

  const isOwner = ticket.user.toString() === req.userId;
  const isAdmin = req.userRole === "admin";

  if (!isOwner && !isAdmin) {
    return res.status(403).json({
      success: false,
      message: "You don't have permission to delete this ticket",
    });
  }

  await ticket.deleteOne();

  res.status(200).json({
    success: true,
    message: "Ticket deleted successfully",
  });
});
module.exports = {
  maketicket,
  getmyTickets,
  addreply,
  getTicketById,
  updateTicket,
  deleteTicket, 
};










for zooj inn LOnumber : 
if (zooje %2 == 0) :
    print(zooj)
    else:
    ..........