const express = require("express");
const db = require("./config/db");

const userrouter = require("./Router/user.router");
const ticketRouetr = require("./Router/ticket.router");
const authMiddleware = require("./middleware/auth");

require("dotenv").config();

const PORT = process.env.PORT;

const app = express();

// middlewares
app.use(express.json());


// Routers
app.use("/api", userrouter.router);
app.use("/api", ticketRouetr.router);

db.DB();

app.listen(PORT, () => {
  console.log(`running on port${PORT}`);
});
